IA 3 
Zakiy Manigo
UNI: ztm2106

When running the webpage, run the server and take the IP address give and search it in a web browser. The .js and .css file must be in a static directory and the html file must be in a template directory. Ensure the server is running before accessing the webpage.
If you make changes to the CSS or JavaScript files, refresh the webpage to see the updates.

link to video demonstration: https://youtu.be/mAP3ojzfStg?feature=shared